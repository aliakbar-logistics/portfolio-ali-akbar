"use client";

import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { projects } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function Projects() {
  return (
    <section id="projects" className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            eyebrow="Featured Work"
            heading="Case studies, once the client work lands here."
            description="These cards are wired up and ready — the entries below are sample placeholders. Swap in your own case studies to replace them."
          />
        </div>

        <div className="mt-14 grid md:grid-cols-2 gap-6">
          {projects.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: (i % 2) * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="group relative overflow-hidden rounded-2xl border border-ink-700 bg-ink-800/40 hover:border-gold/50 transition-colors duration-300"
            >
              <div className="relative h-44 overflow-hidden bg-gradient-to-br from-ink-700 to-ink-800">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="font-display text-4xl text-paper/10 group-hover:scale-110 transition-transform duration-500 ease-out">
                    {p.title.split(" ")[0]}
                  </span>
                </div>
                {p.isDemo && (
                  <span className="absolute top-3 left-3 font-mono text-[10px] uppercase tracking-wider bg-ink/80 text-gold border border-gold/40 rounded-full px-2.5 py-1">
                    Demo Placeholder
                  </span>
                )}
              </div>

              <div className="p-6">
                <span className="eyebrow text-teal">{p.category}</span>
                <h3 className="mt-2 font-display text-xl text-paper flex items-center gap-2">
                  {p.title}
                  <ArrowUpRight
                    size={16}
                    className="opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all duration-300 text-gold"
                  />
                </h3>
                <p className="mt-2 text-sm text-paper/55 leading-relaxed">{p.description}</p>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {p.tags.map((t) => (
                    <span key={t} className="text-[11px] text-paper/40 border border-ink-700 rounded-full px-2.5 py-1">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
