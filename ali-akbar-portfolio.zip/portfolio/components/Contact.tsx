"use client";

import { motion } from "framer-motion";
import { Mail, Phone, Clock } from "lucide-react";
import { profile } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function Contact() {
  return (
    <section id="contact" className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid md:grid-cols-2 gap-14">
          <div>
            <SectionHeading
              eyebrow="Contact"
              heading="Let's build a ranking strategy that pays for itself."
              description="Tell me a bit about your site and goals — I'll reply within 24 hours with next steps."
            />

            <div className="mt-10 space-y-4">
              <a href={`mailto:${profile.email}`} className="flex items-center gap-3 text-paper/70 hover:text-gold transition-colors">
                <Mail size={18} className="text-teal" /> {profile.email}
              </a>
              <a href={`tel:${profile.phone.replace(/\s/g, "")}`} className="flex items-center gap-3 text-paper/70 hover:text-gold transition-colors">
                <Phone size={18} className="text-teal" /> {profile.phone}
              </a>
              <div className="flex items-center gap-3 text-paper/50">
                <Clock size={18} className="text-teal" /> Replies within 24 hours
              </div>
            </div>
          </div>

          <motion.form
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            action={`mailto:${profile.email}`}
            method="post"
            encType="text/plain"
            className="space-y-4 rounded-2xl border border-ink-700 bg-ink-800/40 p-6 md:p-8"
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <input
                required
                name="name"
                placeholder="Name"
                className="rounded-lg bg-ink border border-ink-700 px-4 py-3 text-sm text-paper placeholder:text-paper/30 focus:border-gold outline-none transition-colors"
              />
              <input
                required
                type="email"
                name="email"
                placeholder="Email"
                className="rounded-lg bg-ink border border-ink-700 px-4 py-3 text-sm text-paper placeholder:text-paper/30 focus:border-gold outline-none transition-colors"
              />
            </div>
            <input
              name="company"
              placeholder="Company (optional)"
              className="w-full rounded-lg bg-ink border border-ink-700 px-4 py-3 text-sm text-paper placeholder:text-paper/30 focus:border-gold outline-none transition-colors"
            />
            <textarea
              required
              name="details"
              rows={4}
              placeholder="Tell me about your project"
              className="w-full rounded-lg bg-ink border border-ink-700 px-4 py-3 text-sm text-paper placeholder:text-paper/30 focus:border-gold outline-none transition-colors resize-none"
            />
            <button
              type="submit"
              className="w-full rounded-lg bg-gold text-ink font-medium py-3.5 hover:bg-gold-light transition-colors"
            >
              Request a Quote
            </button>
            <p className="text-xs text-paper/35 text-center">
              Opens your email app with this message pre-filled.
            </p>
          </motion.form>
        </div>
      </div>
    </section>
  );
}
