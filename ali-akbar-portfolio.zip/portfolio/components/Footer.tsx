import { profile } from "@/lib/data";

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="border-t border-ink-700/60 py-10">
      <div className="mx-auto max-w-6xl px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-center md:text-left">
          <p className="font-display text-paper">
            Ali<span className="text-gold">.</span>Akbar
          </p>
          <p className="text-xs text-paper/40 mt-1">SEO & Digital Marketing Specialist</p>
        </div>
        <p className="text-xs text-paper/35">© {year} {profile.name}. All rights reserved.</p>
      </div>
    </footer>
  );
}
