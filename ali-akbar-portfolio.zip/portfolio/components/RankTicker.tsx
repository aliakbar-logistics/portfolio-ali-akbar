import { heroTicker } from "@/lib/data";
import { ArrowUp } from "lucide-react";

export default function RankTicker() {
  const doubled = [...heroTicker, ...heroTicker];

  return (
    <div className="relative w-full overflow-hidden border-y border-ink-700/70 bg-ink-800/50 backdrop-blur-sm mask-fade-x">
      <div className="flex w-max animate-ticker py-3">
        {doubled.map((item, i) => (
          <div
            key={i}
            className="flex items-center gap-3 px-6 border-r border-ink-700/60 whitespace-nowrap"
          >
            <span className="font-mono text-[11px] text-paper/40">#{String(i % heroTicker.length + 1).padStart(2, "0")}</span>
            <span className="text-sm text-paper/70">{item.term}</span>
            <span className="font-mono text-xs px-2 py-0.5 rounded-full bg-ink-700 text-teal">
              rank {item.rank}
            </span>
            <span className="flex items-center gap-0.5 font-mono text-xs text-gold">
              <ArrowUp size={12} strokeWidth={3} /> {item.delta}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
