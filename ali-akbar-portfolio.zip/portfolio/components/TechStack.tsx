"use client";

import { techStack } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function TechStack() {
  const doubled = [...techStack, ...techStack];
  return (
    <section className="py-20 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading eyebrow="Tech Stack" heading="Built and optimized with." align="center" />
      </div>
      <div className="mt-10 overflow-hidden mask-fade-x">
        <div className="flex w-max gap-10 animate-ticker">
          {doubled.map((tech, i) => (
            <span
              key={i}
              className="font-display text-2xl md:text-3xl text-paper/20 hover:text-teal transition-colors duration-300 whitespace-nowrap"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
