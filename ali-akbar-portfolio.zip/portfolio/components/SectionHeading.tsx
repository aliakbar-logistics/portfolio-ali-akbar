"use client";

import { motion } from "framer-motion";
import { ReactNode } from "react";

export default function SectionHeading({
  eyebrow,
  heading,
  description,
  align = "left",
}: {
  eyebrow: string;
  heading: ReactNode;
  description?: string;
  align?: "left" | "center";
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className={`max-w-2xl ${align === "center" ? "mx-auto text-center" : ""}`}
    >
      <span className="eyebrow text-teal">{eyebrow}</span>
      <h2 className="mt-3 font-display text-3xl md:text-4xl tracking-tight text-paper text-balance">
        {heading}
      </h2>
      {description && (
        <p className="mt-4 text-paper/60 leading-relaxed">{description}</p>
      )}
    </motion.div>
  );
}
