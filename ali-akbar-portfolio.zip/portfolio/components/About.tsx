"use client";

import { motion } from "framer-motion";
import { about } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function About() {
  return (
    <section id="about" className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid md:grid-cols-[1fr_1.2fr] gap-12 md:gap-20">
          <SectionHeading
            eyebrow={about.eyebrow}
            heading={about.heading}
          />

          <div className="space-y-5">
            {about.paragraphs.map((p, i) => (
              <motion.p
                key={i}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.6, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
                className="text-paper/65 leading-relaxed"
              >
                {p}
              </motion.p>
            ))}

            <div className="grid grid-cols-3 gap-6 pt-8 mt-4 border-t border-ink-700/60">
              {about.stats.map((s, i) => (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                >
                  <div className="font-display text-2xl md:text-3xl text-gold">{s.value}</div>
                  <div className="mt-1 text-xs text-paper/50 leading-snug">{s.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
