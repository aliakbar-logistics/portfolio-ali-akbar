"use client";

import { motion, useScroll, useSpring, useTransform } from "framer-motion";
import { useEffect, useState } from "react";

export default function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 26, restDelta: 0.001 });
  const percentValue = useTransform(scrollYProgress, (v) => Math.round(v * 100));
  const [percent, setPercent] = useState(0);

  useEffect(() => {
    const unsubscribe = percentValue.on("change", (v) => setPercent(v));
    return unsubscribe;
  }, [percentValue]);

  return (
    <div className="fixed top-0 left-0 right-0 z-50 pointer-events-none">
      <motion.div
        style={{ scaleX }}
        className="h-[2px] origin-left bg-gradient-to-r from-teal via-gold to-gold-light"
      />
      <div className="hidden md:flex justify-end pr-6 pt-1">
        <span className="eyebrow text-[10px] text-paper/40">
          {percent < 100 ? `crawling · ${percent}%` : "indexed · 100%"}
        </span>
      </div>
    </div>
  );
}
