"use client";

import { motion } from "framer-motion";
import { experience } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function Experience() {
  return (
    <section id="experience" className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading eyebrow="Experience" heading="Where the hands-on learning happened." />

        <div className="mt-14 space-y-0">
          {experience.map((e, i) => (
            <motion.div
              key={e.role}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="grid md:grid-cols-[220px_1fr] gap-4 md:gap-10 py-8 border-b border-ink-700/60 last:border-none"
            >
              <div>
                <span className="font-mono text-xs text-teal">{e.period}</span>
                <h3 className="mt-1 font-display text-xl text-paper">{e.role}</h3>
                <p className="text-sm text-paper/45">{e.org}</p>
              </div>
              <ul className="space-y-2">
                {e.points.map((pt) => (
                  <li key={pt} className="flex gap-3 text-paper/65 leading-relaxed text-sm">
                    <span className="mt-2 h-1 w-1 rounded-full bg-gold shrink-0" />
                    {pt}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
