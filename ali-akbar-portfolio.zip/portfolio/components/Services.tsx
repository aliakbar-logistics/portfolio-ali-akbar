"use client";

import { motion } from "framer-motion";
import { services } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function Services() {
  return (
    <section id="services" className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="Services"
          heading="Everything a search ranking depends on."
          description="A focused set of services covering strategy, technical health, content, and outreach — under one roof."
        />

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="group relative rounded-2xl border border-ink-700 bg-ink-800/40 p-6 hover:border-gold/50 hover:bg-ink-800/70 transition-all duration-300"
            >
              <span className="font-mono text-xs text-paper/30">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="mt-3 font-display text-lg text-paper group-hover:text-gold transition-colors">
                {s.title}
              </h3>
              <p className="mt-2 text-sm text-paper/55 leading-relaxed">{s.description}</p>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {s.tags.map((t) => (
                  <span
                    key={t}
                    className="font-mono text-[10px] uppercase tracking-wider text-teal/80 bg-teal/10 rounded-full px-2 py-1"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
