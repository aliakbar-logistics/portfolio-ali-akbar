"use client";

import { motion } from "framer-motion";
import { achievements } from "@/lib/data";
import AnimatedCounter from "./AnimatedCounter";

export default function Achievements() {
  return (
    <section className="py-20 border-t border-ink-700/60 bg-ink-800/30">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {achievements.map((a, i) => (
            <motion.div
              key={a.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="text-center md:text-left"
            >
              <AnimatedCounter value={a.value} suffix={a.suffix} />
              <p className="mt-2 text-xs text-paper/50 leading-snug max-w-[14ch] mx-auto md:mx-0">
                {a.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
