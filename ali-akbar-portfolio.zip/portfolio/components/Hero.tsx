"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, MapPin } from "lucide-react";
import MagneticButton from "./MagneticButton";
import RankTicker from "./RankTicker";
import { profile } from "@/lib/data";

const fadeUp = {
  hidden: { opacity: 0, y: 24, filter: "blur(6px)" },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { delay: i * 0.1, duration: 0.7, ease: [0.16, 1, 0.3, 1] },
  }),
};

export default function Hero() {
  return (
    <section id="top" className="relative pt-40 pb-16 md:pt-48 md:pb-20 overflow-hidden">
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          custom={0}
          initial="hidden"
          animate="show"
          variants={fadeUp}
          className="inline-flex items-center gap-2 rounded-full border border-ink-700 bg-ink-800/60 px-4 py-1.5 mb-8"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-teal" />
          </span>
          <span className="eyebrow text-paper/70">{profile.availability}</span>
        </motion.div>

        <motion.h1
          custom={1}
          initial="hidden"
          animate="show"
          variants={fadeUp}
          className="font-display text-balance text-[2.5rem] leading-[1.05] sm:text-6xl md:text-7xl tracking-tight max-w-4xl"
        >
          Every ranking tells a story.
          <br />
          <span className="text-gold">I write the ones that end at #1.</span>
        </motion.h1>

        <motion.p
          custom={2}
          initial="hidden"
          animate="show"
          variants={fadeUp}
          className="mt-8 max-w-2xl text-lg text-paper/65 leading-relaxed"
        >
          I'm {profile.name}, an SEO & Digital Marketing Specialist helping USA and
          Canada-based businesses turn search visibility into revenue — through
          technical SEO, local SEO, and link building that actually moves the needle.
        </motion.p>

        <motion.div
          custom={3}
          initial="hidden"
          animate="show"
          variants={fadeUp}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <MagneticButton
            href="#projects"
            className="inline-flex items-center gap-2 rounded-full bg-gold text-ink px-6 py-3.5 font-medium hover:bg-gold-light transition-colors"
          >
            View Portfolio <ArrowUpRight size={18} />
          </MagneticButton>
          <MagneticButton
            href="#contact"
            className="inline-flex items-center gap-2 rounded-full border border-ink-700 px-6 py-3.5 font-medium text-paper hover:border-teal hover:text-teal transition-colors"
          >
            Hire Me
          </MagneticButton>

          <span className="flex items-center gap-1.5 text-sm text-paper/50 ml-2">
            <MapPin size={14} /> {profile.location}
          </span>
        </motion.div>
      </div>

      <motion.div
        custom={4}
        initial="hidden"
        animate="show"
        variants={fadeUp}
        className="mt-16"
      >
        <RankTicker />
      </motion.div>
    </section>
  );
}
