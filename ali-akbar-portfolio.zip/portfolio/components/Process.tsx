"use client";

import { motion } from "framer-motion";
import { process } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function Process() {
  return (
    <section id="process" className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading eyebrow="Working Process" heading="From audit to ranking, in five stages." />

        <div className="mt-14 relative">
          <div className="hidden md:block absolute left-[1.55rem] top-2 bottom-2 w-px bg-ink-700" />
          <div className="space-y-10">
            {process.map((s, i) => (
              <motion.div
                key={s.step}
                initial={{ opacity: 0, x: -16 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="relative flex gap-6 md:gap-8 pl-0 md:pl-0"
              >
                <div className="relative z-10 shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-ink-800 border border-gold/50 font-mono text-sm text-gold">
                  {s.step}
                </div>
                <div className="pt-1.5">
                  <h3 className="font-display text-lg text-paper">{s.title}</h3>
                  <p className="mt-1.5 text-sm text-paper/55 leading-relaxed max-w-xl">{s.body}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
