"use client";

import { motion } from "framer-motion";
import { whyWorkWithMe } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function WhyWorkWithMe() {
  return (
    <section className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="Why Work With Me"
          heading="Built for clients who want results, not reports for their own sake."
        />

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-10">
          {whyWorkWithMe.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
            >
              <div className="h-px w-8 bg-gold mb-4" />
              <h3 className="font-display text-lg text-paper">{item.title}</h3>
              <p className="mt-2 text-sm text-paper/55 leading-relaxed">{item.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
