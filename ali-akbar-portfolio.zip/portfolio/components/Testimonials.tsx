"use client";

import { motion } from "framer-motion";
import { Quote } from "lucide-react";
import { testimonials } from "@/lib/data";
import SectionHeading from "./SectionHeading";

export default function Testimonials() {
  return (
    <section className="py-24 md:py-32 border-t border-ink-700/60">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          eyebrow="Testimonials"
          heading="What clients will say — once the reviews come in."
          description="These are placeholder quotes so the layout is ready. Replace them with real feedback from your clients."
        />

        <div className="mt-14 grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="relative rounded-2xl border border-dashed border-ink-700 bg-ink-800/30 p-6"
            >
              {t.isDemo && (
                <span className="absolute top-4 right-4 font-mono text-[10px] uppercase tracking-wider text-gold/70">
                  Placeholder
                </span>
              )}
              <Quote size={20} className="text-teal/60" />
              <p className="mt-4 text-sm text-paper/60 leading-relaxed italic">{t.quote}</p>
              <div className="mt-5 pt-4 border-t border-ink-700/60">
                <p className="text-sm text-paper/80">{t.name}</p>
                <p className="text-xs text-paper/40">{t.title}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
