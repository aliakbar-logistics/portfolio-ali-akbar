import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Experience from "@/components/Experience";
import Skills from "@/components/Skills";
import Services from "@/components/Services";
import Projects from "@/components/Projects";
import Achievements from "@/components/Achievements";
import WhyWorkWithMe from "@/components/WhyWorkWithMe";
import Process from "@/components/Process";
import Testimonials from "@/components/Testimonials";
import TechStack from "@/components/TechStack";
import FAQ from "@/components/FAQ";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="relative">
      <Navbar />
      <Hero />
      <Achievements />
      <About />
      <Services />
      <Skills />
      <Projects />
      <Experience />
      <Process />
      <WhyWorkWithMe />
      <TechStack />
      <Testimonials />
      <FAQ />
      <Contact />
      <Footer />
    </main>
  );
}
