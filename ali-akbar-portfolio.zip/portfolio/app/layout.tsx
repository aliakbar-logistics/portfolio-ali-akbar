import type { Metadata } from "next";
import { Space_Grotesk, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import ScrollProgress from "@/components/ScrollProgress";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const plexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-plex-mono",
  display: "swap",
});

const siteUrl = "https://aliakbar.dev"; // TODO: replace with real deployed domain

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Ali Akbar — SEO Specialist & Digital Marketing Strategist",
    template: "%s — Ali Akbar",
  },
  description:
    "Ali Akbar is an SEO Specialist and Digital Marketing Strategist based in Lahore, helping USA & Canada businesses grow organic visibility through technical SEO, local SEO, and link building.",
  keywords: [
    "Ali Akbar", "SEO Specialist", "Technical SEO", "Local SEO", "Link Building",
    "Digital Marketing Specialist", "WordPress SEO", "Google Business Profile Optimization",
  ],
  authors: [{ name: "Ali Akbar" }],
  creator: "Ali Akbar",
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    url: siteUrl,
    title: "Ali Akbar — SEO Specialist & Digital Marketing Strategist",
    description:
      "SEO & Digital Marketing Specialist helping USA & Canada businesses turn search visibility into revenue.",
    siteName: "Ali Akbar Portfolio",
    images: [{ url: "/og-image.jpg", width: 1200, height: 630, alt: "Ali Akbar — SEO Specialist" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Ali Akbar — SEO Specialist & Digital Marketing Strategist",
    description:
      "SEO & Digital Marketing Specialist helping USA & Canada businesses turn search visibility into revenue.",
    images: ["/og-image.jpg"],
  },
  robots: { index: true, follow: true },
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: "Ali Akbar — SEO & Digital Marketing",
  founder: {
    "@type": "Person",
    name: "Ali Akbar",
    jobTitle: "SEO Specialist & Digital Marketing Strategist",
    address: { "@type": "PostalAddress", addressLocality: "Lahore", addressCountry: "PK" },
    knowsAbout: [
      "Search Engine Optimization", "Technical SEO", "Local SEO", "Link Building",
      "WordPress SEO", "Digital Marketing", "Google Business Profile Optimization",
    ],
  },
  areaServed: ["United States", "Canada", "Pakistan"],
  url: siteUrl,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${spaceGrotesk.variable} ${inter.variable} ${plexMono.variable}`}>
      <body className="font-body antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <div className="grain-overlay" aria-hidden="true" />
        <ScrollProgress />
        {children}
      </body>
    </html>
  );
}
