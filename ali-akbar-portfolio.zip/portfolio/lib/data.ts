// ─────────────────────────────────────────────────────────────
// All site copy and structured content lives here.
// Edit this file to update the site without touching components.
// Anything marked "DEMO PLACEHOLDER" is temporary sample content
// and should be replaced with your real projects/numbers/testimonials.
// ─────────────────────────────────────────────────────────────

export const profile = {
  name: "Ali Akbar",
  role: "SEO Specialist & Digital Marketing Strategist",
  location: "Lahore, Pakistan",
  email: "hello@aliakbar.dev", // TODO: replace with real email
  phone: "+92 3XX XXXXXXX", // TODO: replace with real number
  availability: "Open to freelance & full-time roles · 2026",
};

export const heroTicker = [
  { term: "local seo — lahore hvac client", rank: 1, delta: 12 },
  { term: "technical seo audit — ecommerce", rank: 3, delta: 9 },
  { term: "wordpress speed optimization", rank: 2, delta: 15 },
  { term: "link building — saas client", rank: 4, delta: 21 },
  { term: "google business profile optimization", rank: 1, delta: 6 },
  { term: "on-page content strategy", rank: 3, delta: 11 },
];

export const about = {
  eyebrow: "About Ali",
  heading: "I got hooked on the moment a page climbs to #1.",
  paragraphs: [
    "It started with a simple question: why does one page outrank a hundred others that say almost the same thing? Chasing that answer turned into a career. I spend my days inside Search Console dashboards, crawl reports, and backlink profiles, looking for the one fix that moves a client from page three to page one.",
    "Most of my hands-on experience has come from working with small and mid-sized businesses across the USA and Canada — cleaning up technical debt on WordPress sites, rebuilding local listings from scratch, and running outreach campaigns that earn links instead of buying them.",
    "I'm not precious about tools or trends. If Google changes the rules, I change my approach. Lately that means folding AI and automation into my workflow — not to replace the strategy, but to do the repetitive parts faster so I can spend more time on the decisions that actually move rankings.",
    "The goal is always the same: visibility that turns into inquiries, and inquiries that turn into revenue. Everything else is a means to that end.",
  ],
  stats: [
    { label: "Years hands-on in SEO", value: "2+" },
    { label: "Sites audited & optimized", value: "15+" },
    { label: "Avg. organic traffic lift", value: "140%" },
  ],
};

export const services = [
  {
    title: "Search Engine Optimization",
    description: "Full-funnel SEO strategy that connects keyword research, content, and technical health into one plan.",
    tags: ["Strategy", "Roadmapping", "Reporting"],
  },
  {
    title: "Technical SEO",
    description: "Crawl audits, indexing fixes, Core Web Vitals, and site architecture cleanup so search engines can actually find your best pages.",
    tags: ["Site Audits", "Core Web Vitals", "Schema"],
  },
  {
    title: "Local SEO",
    description: "Google Business Profile optimization, citation building, and location pages built to win the map pack.",
    tags: ["GBP", "Citations", "Map Pack"],
  },
  {
    title: "Keyword Research",
    description: "Demand and intent mapping that finds the keywords your customers actually type — not just the ones with big volume.",
    tags: ["Intent Mapping", "Competitor Gaps"],
  },
  {
    title: "Link Building",
    description: "Manual outreach and digital PR that earns links from relevant, real sites — no link farms, no shortcuts.",
    tags: ["Outreach", "Digital PR", "Guest Posts"],
  },
  {
    title: "SEO Audit",
    description: "A full diagnostic of technical, on-page, and off-page health, delivered as a prioritized action plan.",
    tags: ["Diagnostics", "Prioritized Fixes"],
  },
  {
    title: "WordPress SEO",
    description: "Theme, plugin, and structure cleanup so your WordPress site is fast, crawlable, and built to rank.",
    tags: ["Speed", "Structure", "Plugins"],
  },
  {
    title: "Google Business Profile Optimization",
    description: "Category, service, review, and post strategy that turns your profile into a lead source.",
    tags: ["Reviews", "Categories", "Posts"],
  },
  {
    title: "Content Strategy",
    description: "Content calendars and briefs built around search intent, so every page has a job to do.",
    tags: ["Briefs", "Calendars", "Intent"],
  },
  {
    title: "AI Automation",
    description: "Workflows that use AI tools to speed up research, reporting, and content production without losing quality control.",
    tags: ["Workflows", "Reporting", "Research"],
  },
  {
    title: "Website Optimization",
    description: "Speed, UX, and conversion cleanup so traffic you've already earned actually turns into leads.",
    tags: ["Speed", "UX", "Conversion"],
  },
];

export const skillGroups = [
  {
    group: "SEO",
    items: ["Technical SEO", "Local SEO", "On-Page SEO", "Off-Page SEO", "Link Building", "Keyword Research"],
  },
  {
    group: "Tools & Platforms",
    items: ["Google Search Console", "Google Analytics", "WordPress", "Canva", "Google Business Profile"],
  },
  {
    group: "Marketing & Growth",
    items: ["Digital Marketing", "Content Writing", "Outreach", "Lead Generation", "Campaign Planning"],
  },
  {
    group: "AI & Automation",
    items: ["AI Tools", "Workflow Automation", "Prompt-driven Research"],
  },
  {
    group: "Core Strengths",
    items: ["Communication", "Problem Solving", "Analytical Thinking", "Attention to Detail"],
  },
];

// DEMO PLACEHOLDER — these titles/categories are sample projects for layout
// purposes only, based on a public reference portfolio. Replace every entry
// below with your own real client work before publishing. Do not present
// these as your own delivered projects.
export const projects = [
  {
    category: "Local Service — Demo",
    title: "Local Electrical Services Site (Sample)",
    description: "Placeholder case study: a lead-focused local service site with location pages and review-driven trust signals.",
    tags: ["Local SEO", "Lead Gen", "Service Pages"],
    isDemo: true,
  },
  {
    category: "E-commerce — Demo",
    title: "Premium Retail Storefront (Sample)",
    description: "Placeholder case study: a product-led storefront optimized for organic discovery and mobile conversion.",
    tags: ["Ecommerce SEO", "Mobile First", "Conversion"],
    isDemo: true,
  },
  {
    category: "HVAC / Home Services — Demo",
    title: "Home Services Lead Generator (Sample)",
    description: "Placeholder case study: a regional home-services brand rebuilt around local trust signals and speed.",
    tags: ["Local SEO", "Speed", "Trust Signals"],
    isDemo: true,
  },
  {
    category: "Healthcare Tech — Demo",
    title: "Care-Matching Platform (Sample)",
    description: "Placeholder case study: a healthcare platform optimized for conversion-focused organic landing pages.",
    tags: ["Healthcare", "Conversion", "Content"],
    isDemo: true,
  },
  {
    category: "Corporate — Demo",
    title: "Community Organization Site (Sample)",
    description: "Placeholder case study: a corporate/nonprofit rebuild focused on clarity, speed, and crawlability.",
    tags: ["Corporate", "Performance", "Accessibility"],
    isDemo: true,
  },
];

export const experience = [
  {
    role: "SEO Intern",
    org: "Client & Agency Projects", // TODO: replace with real company name
    period: "2024 — Present",
    points: [
      "Ran technical and on-page audits for USA/Canada-based client sites, identifying indexing, crawl, and content gaps.",
      "Optimized on-site structure, metadata, and internal linking to improve organic visibility for target keywords.",
      "Supported keyword research and content briefs used by writers to produce search-optimized pages.",
    ],
  },
  {
    role: "Digital Marketing Associate",
    org: "Freelance & Contract Work", // TODO: replace with real company name
    period: "2023 — 2024",
    points: [
      "Executed multi-channel digital marketing campaigns aligned to client acquisition goals.",
      "Managed Google Business Profile optimization for local clients, improving map pack visibility.",
      "Coordinated outreach for link building, securing placements on relevant industry sites.",
    ],
  },
  {
    role: "Marketing Campaigns Coordinator",
    org: "Freelance & Contract Work", // TODO: replace with real company name
    period: "2023",
    points: [
      "Planned and tracked marketing campaigns from brief through reporting.",
      "Built simple performance dashboards to communicate results to stakeholders in plain language.",
    ],
  },
  {
    role: "Accounting Experience",
    org: "Prior Role", // TODO: replace with real company name
    period: "2022 — 2023",
    points: [
      "Built a foundation in analytical accuracy, reconciliation, and structured reporting — skills now applied to SEO performance tracking.",
      "Developed close attention to detail that carries directly into technical audits and data-driven decisions.",
    ],
  },
];

export const achievements = [
  { value: 2, suffix: "+", label: "Years hands-on SEO experience" },
  { value: 15, suffix: "+", label: "Businesses supported" },
  { value: 140, suffix: "%", label: "Avg. organic traffic growth" }, // TODO: replace with your verified figure
  { value: 300, suffix: "+", label: "Keywords moved to page 1" }, // TODO: replace with your verified figure
];

export const whyWorkWithMe = [
  { title: "Data before opinions", body: "Every recommendation is backed by Search Console, analytics, or crawl data — not guesswork." },
  { title: "Plain-language reporting", body: "You'll always know what changed, why, and what it's doing for your rankings." },
  { title: "Technical + creative", body: "I fix the crawl errors and write the content brief — no hand-offs lost in translation." },
  { title: "Built for North American clients", body: "Comfortable working async across USA/Canada time zones with clear, regular check-ins." },
  { title: "AI-assisted, human-checked", body: "Automation speeds up research and reporting; every strategic call is still mine." },
  { title: "Honest about timelines", body: "SEO compounds — I'll tell you what's realistic in 30 days versus 6 months." },
];

export const process = [
  { step: "01", title: "Discovery & Audit", body: "Full technical, on-page, and competitive audit to find the highest-leverage fixes." },
  { step: "02", title: "Strategy & Roadmap", body: "A prioritized plan mapped to your business goals, not vanity metrics." },
  { step: "03", title: "Technical & On-Page Fixes", body: "Crawl, indexing, speed, structure, and content optimization, shipped in order of impact." },
  { step: "04", title: "Content & Link Building", body: "Search-intent content and relevant outreach to build authority the right way." },
  { step: "05", title: "Reporting & Iteration", body: "Clear monthly reporting and a roadmap that adapts as rankings and algorithms move." },
];

// DEMO PLACEHOLDER — sample quotes for layout only. Replace with real testimonials.
export const testimonials = [
  {
    quote: "Placeholder testimonial — replace with a real client quote about results and communication.",
    name: "Client Name",
    title: "Role, Company",
    isDemo: true,
  },
  {
    quote: "Placeholder testimonial — replace with a real client quote about turnaround and technical depth.",
    name: "Client Name",
    title: "Role, Company",
    isDemo: true,
  },
  {
    quote: "Placeholder testimonial — replace with a real client quote about ranking improvements.",
    name: "Client Name",
    title: "Role, Company",
    isDemo: true,
  },
];

export const faqs = [
  {
    q: "How long does SEO take to show results?",
    a: "Technical fixes can move the needle within a few weeks. Competitive keyword growth typically takes 3–6 months of consistent work — I'll give you a realistic timeline after the initial audit.",
  },
  {
    q: "Do you work with businesses outside Pakistan?",
    a: "Yes — most of my hands-on experience is with USA and Canada-based businesses, and I structure communication around your time zone.",
  },
  {
    q: "Do you write content, or only handle technical SEO?",
    a: "Both. I build the content strategy and briefs, and can coordinate with your writers or handle drafts myself depending on scope.",
  },
  {
    q: "What platforms do you work with?",
    a: "Primarily WordPress, alongside Google Search Console, Google Analytics, and standard local-SEO and outreach tooling.",
  },
  {
    q: "How do you report on progress?",
    a: "Monthly reporting in plain language: what changed, why, ranking movement, and what's next — no jargon-only dashboards.",
  },
];

export const techStack = [
  "Next.js", "React", "TypeScript", "Tailwind CSS", "Framer Motion",
  "WordPress", "Google Search Console", "Google Analytics", "Screaming Frog", "AI Workflow Tools",
];
